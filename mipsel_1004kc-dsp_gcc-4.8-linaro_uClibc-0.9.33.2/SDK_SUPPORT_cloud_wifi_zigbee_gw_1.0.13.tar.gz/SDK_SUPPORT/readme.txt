文件说明：
include：应用相关头文件
libs：用户代码关联库
user_main.c：样例文件
	
编译说明：
1 打开Makefile文件，设置变量COMPILE_PREX ?= 具体交叉编译工具链的绝对路径(必选)，SOFT_NAME = XXX 生成可执行文件名（可选），
 VERSION = x.x.x（可选）
2 执行：make，生成SOFT_NAME_VERSION,默认生成iot_contro_l.1.1
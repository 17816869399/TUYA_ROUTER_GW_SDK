/*******************************************************************************************************
**                                           File description
** File Name:           user_main.c
** Description:         接口函数使用
** Creator:             Bumblebee
** Creation Date:       2018年12月5日
** Modify Log:          none
** Last Modified Date:  2018年12月5日
*******************************************************************************************************/
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "tuya_export_gateway.h"
#include "tuya_export_type.h"

// 涂鸦云上的产品KEY，不同产品KEY不相同，需登陆tuya.com创建产品分配唯一key
#define PRODUCT_KEY "GXxoKf27eVjA7x1c" // 此key可用于测试

#define UUID  "003tuyatestf7f149185"
#define AUTHKEY "NeA8Wc7srpAZHEMuru867oblOLN2QCC1"

/*
   iTime=0 配网灯灭
   iTime=1 配网灯亮
   iTime>50 配网灯闪烁，闪烁的时间 间隔是iTime MS
   */
int user_dev_led_control(unsigned int iTime)
{
    //LED灯控制函数
    return 0;
}

int user_get_uuid_authkey(char *p_uuid, int uuid_buf_size, char *p_authkey, int authkey_buf_size)
{
    //获取认证信息
    strncpy(p_uuid,UUID,uuid_buf_size);
    strncpy(p_authkey,AUTHKEY,authkey_buf_size);

    return 0;
}

int user_get_product_key(char *product_key,int buf_size)
{
    strncpy(product_key,PRODUCT_KEY,buf_size);
    return 0;
}

int user_get_ssid_psk(char *p_ssid, int ssid_buf_size, char *p_psk, int  psk_buf_size)
{
    //获取wifi得ssid和psk
    strncpy(p_ssid,"tuya_show",ssid_buf_size);
    strncpy(p_psk,"12345678",psk_buf_size);

    return 0;
}

void user_sdk_reboot()
{
    //这里实现对SDK 进程的重启。
    printf("reboot.....[%s][%d]\r\n",__FUNCTION__,__LINE__);

    system("killall -9 iot_control");
    return;
}

//upgrade_file 下载的升级文件
int user_sdk_upgrade(char *upgrade_file)
{
    //SDK 升级要做的事情：1 用upgrade_file 替换板子上的SDK进程文件，2 重启SDK进程
    if(NULL== upgrade_file)
    {
        return -1;
    }

    char buf[256] = {0};
    snprintf(buf,256,"cp %s ./iot_control",upgrade_file);
    system(buf);

    return 0;
}

/***********************************************************
 *  Function: main
 *  Input: argc argv
 *  Output: none
 *  Return: int
 ***********************************************************/
int main(int argc,char **argv)
{
    int ret = tuya_set_storge_path("./");
    if (ret != 0) {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    tuya_log_level(TUYA_LOG_LEVEL_NOTICE);
    tuya_set_app_ver("1.0.0");

    if(tuya_set_serial_port("/dev/ttyS1",57600))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_callback(CB_CLOUD_GET_UUID_AUTHKEY,user_get_uuid_authkey))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_callback(CB_CLOUD_GET_PRODUCT_KEY,user_get_product_key))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }
#if 0
    //如果没有wifi的功能就不用注册wifi的接口回调函数
    if(tuya_set_callback(CB_WIFI_GET_SSID_PSK,user_get_ssid_psk))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

#endif

    //如果没有led的功能就不用注册led的接口回调函数
    if(tuya_set_callback(CB_DEV_LED_CONTROL,user_dev_led_control))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_callback(CB_SDK_PROCESS_REBOOT,user_sdk_reboot))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_callback(CB_CLOUD_SDK_UPGRADE,user_sdk_upgrade))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_image_file_path("./"))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    if(tuya_set_wan_eth_name(/*"eth1"*/"eth0.2"))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }
#if 0 
    //没有wifi功能，就不需要设置wlan接口名
    if(tuya_set_wifi_eth_name(""))
    {
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }
#endif

    if(tuya_sdk_start())
    {
        sleep(1000);
        printf("error.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
        return -1;
    }

    //为了不使主线程退出，进程就阻塞在这里
    while(1)
    {
        sleep(10);
        printf("pending.....[%s][%d]\r\n",__FUNCTION__,__LINE__);
    }

    return 0;

}

/*******************************************************************************************************
**                                           File description
** File Name:           tuya_export_type.h
** Description:         定义SDK类型
** Creator:             Bumblebee
** Creation Date:       2018年12月5日
** Modify Log:          none
** Last Modified Date:  2018年12月5日
*******************************************************************************************************/


#ifndef __TUYA_EXPORT_TYPE_H
#define __TUYA_EXPORT_TYPE_H

#ifdef __cplusplus
    extern "C" {
#endif

#define CB_CLOUD_GET_UUID_AUTHKEY       1  //获取uuid和authkey
#define CB_WIFI_GET_SSID_PSK            2  //获取wifi得SSID和PSK
#define CB_DEV_LED_CONTROL              3  //注册led 控制函数
#define CB_SDK_PROCESS_REBOOT           4  //sdk编译出来的进程重启
#define CB_CLOUD_GET_PRODUCT_KEY        5  //获取网关的pid
#define CB_CLOUD_SDK_UPGRADE            6  //SDK升级回调

typedef enum {
    KEYPAD_SHORT_KEY,
    KEYPAD_LONG_KEY
} KEYPAD_KEY_t;

/***********************************************************
*  Function: P_DEV_COMMON_LED_CONTROL 对led进行控制
*  Input:  iTime[in]->iTime=0,关闭配网灯；iTime=1，打开配网灯;iTime>50 与iTime时间进行反转闪烁             
*  Output: none
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/
typedef int (*P_USER_DEV_LED_CONTROL)(unsigned int iTime); 

/***********************************************************
*  Function: P_CLOUD_GET_UUID_AUTHKEY 获取uuid 和 authkey
*  Input:  uuid_buf_size[in]->获取uuid buffer的大小
           authkey_buf_size[out]->获取authkey buffer的大小
*  Output: p_uuid[out]->获取uuid的buffer地址
           p_authkey[out]->获取authkey的buffer地址
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/ 
typedef int (*P_CLOUD_GET_UUID_AUTHKEY)(char *p_uuid, int uuid_buf_size, char *p_authkey, int authkey_buf_size);

/***********************************************************
*  Function: P_CLOUD_GET_PRODUCT_KEY 获取网关pid
*  Input:  buf_size[in]->获取pid的buffer大小   
*  Output: product_key[out]->获取pid内存buffer地址
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/ 
typedef int (*P_CLOUD_GET_PRODUCT_KEY)(char *product_key,int buf_size);

/***********************************************************
*  Function: P_WIFI_GET_SSID_PSK 获取ssid 和 psk
*  Input:  ssid_buf_size[in]->获取ssid buffer的大小
           psk_buf_size[out]->获取psk buffer的大小
*  Output: p_ssid[out]->获取ssid的buffer地址
           p_psk[out]->获取psk的buffer地址
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/
typedef int (*P_WIFI_GET_SSID_PSK)(char *p_ssid, int ssid_buf_size, char *p_psk, int  psk_buf_size);

/***********************************************************
*  Function: 重启SDK进程
*  Input:  none
*  Output: none
*  Return: none
*  Date: 
***********************************************************/

typedef void (*P_SDK_PROCESS_REBOOT)();

/***********************************************************
*  Function: SDK升级处理
*  Input:  upgrade_file[in]->升级文件路径
*  Output: none
*  Return: none
*  Date: 
***********************************************************/

typedef int (*P_SDK_PROCESS_UPGRADE)(char *upgrade_file);


#ifdef __cplusplus
}
#endif

#endif



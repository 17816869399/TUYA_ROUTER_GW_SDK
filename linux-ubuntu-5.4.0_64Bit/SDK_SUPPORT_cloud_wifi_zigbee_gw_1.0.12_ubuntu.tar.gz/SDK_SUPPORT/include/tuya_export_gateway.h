/*******************************************************************************************************
**                                           File description
** File Name:           tuya_export_gateway.h
** Description:         定义SDK接口函数
** Creator:             Bumblebee
** Creation Date:       2018年12月5日
** Modify Log:          none
** Last Modified Date:  2018年12月5日
*******************************************************************************************************/


#ifndef __TUYA_EXPORT_GATEWAY_H
#define __TUYA_EXPORT_GATEWAY_H

#ifdef __cplusplus
    extern "C" {
#endif

#include "tuya_export_type.h"

/***********************************************************
*  Function: tuya_set_storge_path 对 SDK 进行初始化处理
*  Input: fs_storge_path[in]->文件存储路径,路径必须对应一个可读写文件系统分区
*  Output: none
*  Return: 0成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_set_storge_path(char *fs_storge_path);

/***********************************************************
*  Function: tuya_set_serial_port 设置串口函数
*  Input: name[in]->串口名称
          baud_rate[in]->串口波特率 ,如果使115200 则需要接硬件流控，如果使57600那么不接硬件流控
*  Output: none
*  Return: 0成功，否则失败
*  Date: 20181204
***********************************************************/
extern int tuya_set_serial_port(char *name,unsigned int baud_rate);

/***********************************************************
*  Function: tuya_set_image_file_path 设置升级固件存放路径
*  Input: path[in]->固件存储路径
*  Output: none
*  Return: 0成功，否则失败
*  Date: 20181204
***********************************************************/
extern int tuya_set_image_file_path(char *path);

/***********************************************************
*  Function: tuya_set_callback 设置回调函数
*  Input: cb_type[in]->回调函数种类
          cb_function[in]->回调函数
*  Output: none
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_set_callback(unsigned char cb_type, void *cb_function);

/***********************************************************
*  Function: tuya_sdk_start 开始函数
*  Input: none
*  Output: none
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_sdk_start();

/***********************************************************
*  Function: tuya_sdk_end SDK 停止运行
*  Input: none
*  Output: none
*  Return: 0 成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_sdk_end();

/***********************************************************
*  Function: tuya_set_wan_eth_name 设置wan口的名称
*  Input: eth_name[in]->wan口名称
*  Output: none
*  Return: 0成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_set_wan_eth_name(char *eth_name);

/***********************************************************
*  Function: tuya_set_wifi_eth_name 设置wlan口的名称
*  Input: eth_name[in]->wlan口名称
*  Output: none
*  Return: 0成功，否则失败
*  Date: 
***********************************************************/
extern int tuya_set_wifi_eth_name(char *eth_name);

extern int tuya_key_handle(KEYPAD_KEY_t key);

extern int tuya_set_app_ver(const char *app_version);

extern int tuya_get_sdk_info(char *sdk_info);

#ifdef __cplusplus
}
#endif

#endif



